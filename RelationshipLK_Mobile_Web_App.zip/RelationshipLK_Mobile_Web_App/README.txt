Relationship.lk Mobile Web App - Demo

This is a phone-friendly frontend prototype.
1. Extract the ZIP.
2. Open index.html in a browser to test it.
3. The current demo stores Likes locally on the device.
4. It is NOT yet connected to the real backend, real payments, real chat, or a production database.

Next development step:
Connect this frontend to the Relationship.lk backend API, then deploy the frontend and backend online.
